const jwt = require('jsonwebtoken');
const generateToken = (userId) => {
  return jwt.sign(
    { userId },
    process.env.JWT_SECRET,
    {
      expiresIn: '30d',
      algorithm: 'HS256'
    }
  );
};
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
  } catch (error) {
    throw new Error('Invalid or expired token');
  }
};
module.exports = { generateToken, verifyToken };