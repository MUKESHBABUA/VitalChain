const express = require('express');
const router = express.Router();
const Statistics = require('../models/Statistics'); 
router.get('/', async (req, res) => {
  try {
    const stats = await Statistics.findOne().sort({ createdAt: -1 });
    if (!stats) {
      return res.status(404).json({ message: 'No statistics data found' });
    }
    res.json({
      diseaseDistribution: stats.diseases,
      ageWiseCases: stats.ageGroups,
      insuranceCoverage: stats.insurance,
      governmentStats: stats.programs,
      initiatives: stats.initiatives
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});
module.exports = router;