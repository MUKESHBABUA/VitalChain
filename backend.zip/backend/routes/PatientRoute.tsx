import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { getCurrentUser } from '../utils/auth';
const PatientRoute = () => {
  const user = getCurrentUser();
  return user?.role === 'patient' ? <Outlet /> : <Navigate to="/login" replace />;
};
export default PatientRoute;