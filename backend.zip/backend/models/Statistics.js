const mongoose = require('mongoose');
const StatisticsSchema = new mongoose.Schema({
  diseases: [
    {
      name: String,
      value: Number
    }
  ],
  ageGroups: [
    {
      age: String,
      count: Number
    }
  ],
  insurance: [
    {
      name: String,
      value: Number
    }
  ],
  programs: [
    {
      title: String,
      description: String
    }
  ],
  initiatives: [String],
  createdAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model('Statistics', StatisticsSchema);