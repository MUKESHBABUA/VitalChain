const User = require('../models/User');
const { generateToken } = require('../config/jwt');
const asyncHandler = require('../middlewares/asyncHandler');
const sanitizeHtml = require('sanitize-html');
const sanitizeInput = (data) => {
  return {
    ...data,
    firstName: sanitizeHtml(data.firstName),
    lastName: sanitizeHtml(data.lastName),
    email: sanitizeHtml(data.email).toLowerCase(),
    phone: sanitizeHtml(data.phone).replace(/\D/g, '').slice(0, 10),
    address: sanitizeHtml(data.address)
  };
};
exports.register = asyncHandler(async (req, res) => {
  const sanitizedData = sanitizeInput(req.body);
  const { firstName, lastName, email, password, phone, address } = sanitizedData;

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.status(400).json({ success: false, message: 'User already exists' });
  }
  const user = await User.create({
    firstName,
    lastName,
    email,
    password,
    phone,
    address
  });
  const token = generateToken(user._id);
  res.status(201).json({
    success: true,
    token,
    user: {
      id: user._id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: user.role
    }
  });
});
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Please provide email and password' });
  }
  const user = await User.findOne({ email }).select('+password');
  if (!user) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
  const token = generateToken(user._id);
  res.status(200).json({
    success: true,
    token,
    user: {
      id: user._id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: user.role
    }
  });
});
exports.getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  res.status(200).json({ success: true, data: user });
});